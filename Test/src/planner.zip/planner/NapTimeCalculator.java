package planner;

import java.util.Scanner;

class NapTimeCalculator{
	public static void main(String args[]){
		
		Scanner sc = new Scanner(System.in);
		
		String startTime;
		String endTime;
		
		int napTime = 0;
		int prevNapTime = 0;
		
		
		Planner.init();
		String startTimeD = Planner.day.startTime;
		
		while(true){
			System.out.print("Do you want to add an appointment? [y/n] ");
			String agree = sc.nextLine();
			if(agree.charAt(0) == 'y' || agree.charAt(0) == 'Y'){
				
				System.out.print("Enter starting time: ");
				startTime = sc.nextLine();
				System.out.print("Enter ending time: ");
				endTime = sc.nextLine();
				System.out.print("Enter appointment: ");
				String appointment = sc.nextLine();

			
				Planner.addAppointment(startTime, endTime, appointment);
			
				napTime = Planner.getNapTime();
				
				if(napTime > prevNapTime){
					prevNapTime = napTime;
					startTimeD = Planner.getStartTime();
				}
			}
			else{
				Planner.close();
				napTime = Planner.getNapTime();
				
				if(napTime > prevNapTime){
					prevNapTime = napTime;
					startTimeD = Planner.getStartTime();
				}
				
				if(prevNapTime < 60)
					System.out.println("You can take longest nap at "+startTimeD+" and it will last for "+prevNapTime+" minutes.");
				else
					System.out.println("You can take longest nap at "+startTimeD+" and it will last for "+prevNapTime/60+" hours "+prevNapTime%60+" minutes ");
				
				int totalFreeTime = Planner.getFreeTime();
				if(totalFreeTime < 60)
					System.out.println("Total free time during whole day is "+totalFreeTime+" minutes");
				else
					System.out.println("Total free time during whole day is "+totalFreeTime/60+" hours "+totalFreeTime%60+" minutes");
				
				break;
			}
		}
			
		
		//System.out.print(napTime);
		sc.close();
	}
}