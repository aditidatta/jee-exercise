package planner;

class Planner{
	static Appointment ap1;
	static Appointment ap2;
	static Schedule day = new Schedule("9:00","17:00",0);
	static Nap nap;
	
	static void init(){
		ap1 = new Appointment(day.startTime,day.startTime,"Work starts");
	}
	
	static void close(){
		ap2 = new Appointment(day.endTime,day.endTime,"Work starts");
	}
	
	static void addAppointment(String st, String et, String name){
		ap2 = new Appointment(st,et,name);
	}
	
	static int getNapTime(){
		nap = new Nap(ap1,ap2);
		ap1 = ap2;
		int napTime = nap.calculateNapTime();
		day.freeTime = day.freeTime + napTime;
		return napTime;
	}
	
	static String getStartTime(){
		return nap.startTime;
	}
	
	static int getFreeTime(){
		return day.freeTime;
	}
}